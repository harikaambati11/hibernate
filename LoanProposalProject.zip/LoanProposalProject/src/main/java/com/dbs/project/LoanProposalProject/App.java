package com.dbs.project.LoanProposalProject;

 

import java.util.Arrays;
import java.util.List;

 

 

 

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

 

 

 

import com.dbs.project.LoanProposalProject.model.Customer;

 

 

 

/**
 * Hello world!
 *
 */
public class App 
{
    private static SessionFactory factory = HibConfig.getSessionFactory();
    public static void main( String[] args )
    {
        Customer c1 = new Customer("Shalini", "Mumbai", "shalini@gmail.com", "Passport", 83789237, false);
        Customer c2 = new Customer("Chandana", "Pune", "chandana@gmail.com", "Aadhar", 9898998, true);
        Customer c3 = new Customer("Gautham", "Hyderabad", "gautham@gmail.com", "License", 19998908, false);
        Customer c4 = new Customer("Raghu", "Hyderabad", "Raghu@gmail.com", "License", 19998908, false);
        Customer c5 = new Customer("Rachita", "Pune", "Rachita@gmail.com", "License", 19998908, false);
        
       // Customer c6 = new Customer("Shravan", "Pune", "Rachita@gmail.com", "License", 19998908, false);
        List<Customer> list = Arrays.asList(c1,c2,c3,c4,c5);
        //insertCustomer(list);
        
        //c6.setCustomerAddress("Hyderabad");
        //deleteCustomer(c6);
        
        //getCustomerById(c6.getCustomerEmailId());
        //getCustomers();
    }
    
    public static void getCustomers()
    {
        Session session = factory.openSession();
        // HQL => hibernate query language
        List<Customer> customers = session.createQuery("from Customer").list();
        session.close();
        for(Customer c:customers)
            System.out.println(c);
    }
    
    public static void getCustomerById(String email)
    {
        Session session = factory.openSession();
        Customer customer = session.get(Customer.class, email);
        session.close();
        System.out.println(customer);
    }
    public static void insertCustomer(List<Customer> customers)
    {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        //try {
        for(Customer c: customers)
            System.out.println("saving ...."+session.save(c));
        
        tx.commit();
        //}catch(Exception e) {
           // System.out.println("error"+e.getMessage());
        //}
        session.close();
    }
    public static void updateCustomer(Customer customer)
    {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(customer);
        tx.commit();
        session.close();
    }
    public static void deleteCustomer(Customer customers)
    {
        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();
        session.delete(customers);
        tx.commit();
        session.close();
    }
}