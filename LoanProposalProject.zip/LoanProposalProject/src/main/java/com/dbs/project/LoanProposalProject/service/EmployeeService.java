package com.dbs.project.LoanProposalProject.service;


import com.dbs.project.LoanProposalProject.model.Employee;

public class EmployeeService {




	public void approveLoan(String eid) throws Exception {


	}
	public boolean searchEmployeeById(String empid)
	{
	
		return true;

	}

	public boolean addEmployee(Employee employee) {
		return true;
	}

}
